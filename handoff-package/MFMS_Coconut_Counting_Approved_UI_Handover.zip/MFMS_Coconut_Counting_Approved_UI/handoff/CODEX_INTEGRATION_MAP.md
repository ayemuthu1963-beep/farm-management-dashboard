# CODEX Integration Map - Coconut Counting UI

## Field Classification & Integration Points

### Input Fields (User-Editable)
- **Total nuts Harvested**: Green gradient panel field
  - Bind to: APK editable field for total harvested nuts
  - Type: Numeric input
  - Validation: Required

### Fixed Display Fields (Read-Only from APK Calculations)
- **A counter**: Calculated total for Grade A
- **B counter**: Calculated total for Grade B
- **TOTAL A**: Mirror of A counter
- **TOTAL B**: Mirror of B counter
- **TOTAL A+B**: Combined A + B total
- **A1 counter**: Grade A detail count
- **B1 counter**: Grade B detail count
- **B2 counter**: Grade B pairs detail count

### Action Buttons (Wire to APK Methods)
- **GRADE A — 200 SEND**: Submit fixed count for Grade A (200 count)
- **GRADE B — 200 SEND**: Submit fixed count for Grade B (200 count)
- **GRADE A — PAIRS SEND**: Submit pairs for Grade A (1-99 range)
- **GRADE B — PAIRS SEND**: Submit pairs for Grade B (1-99 range)
- **HISTORY**: Open APK history dialog/page
- **DATE**: Open APK date picker
- **RESET**: Trigger APK reset with confirmation

## Mock Data Replacement Map
```
gradeA200 → 200 (static)
gradeB200 → 200 (static)
gradeA99 → APK Grade A pairs input
gradeB99 → APK Grade B pairs input
counterA → APK calculated A total
counterB → APK calculated B total
totalA → APK A total (copy of counterA)
totalB → APK B total (copy of counterB)
totalAB → APK combined total
totalNutsHarvested → APK editable field
counterA1 → APK A1 detail
counterB1 → APK B1 detail
counterB2 → APK B2 detail
```

## Integration Steps
1. Replace mockData values with APK state bindings
2. Wire onChange handlers to APK state updates
3. Wire button onClick handlers to APK submission methods
4. Bind display fields to APK calculated values
5. Test on Android 412×915 px viewport
