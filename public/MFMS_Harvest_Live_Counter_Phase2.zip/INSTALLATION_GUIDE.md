# Installation & Setup Guide

## Quick Start

1. **Extract the package** to your project directory
2. **Copy files** maintaining folder structure:
   ```
   app/harvest-live-counter/page.tsx → app/harvest-live-counter/
   lib/harvest-live-counter-mock.ts → lib/
   components/harvest-live-counter/* → components/harvest-live-counter/
   ```

3. **Install dependencies** (if not already installed):
   ```bash
   npm install lucide-react
   ```

4. **Verify TypeScript**:
   ```bash
   npx tsc --noEmit
   ```

5. **Run development server**:
   ```bash
   npm run dev
   ```

6. **Open in browser**:
   ```
   http://localhost:3000/harvest-live-counter
   ```

## Project Requirements

- Next.js 13+ (with App Router)
- React 18+
- TypeScript
- Tailwind CSS
- lucide-react (icons)

## Verify Setup

- [ ] All files copied maintaining paths
- [ ] `npm run dev` starts without errors
- [ ] Page loads at `/harvest-live-counter`
- [ ] Live state displays with "HARVEST IN PROGRESS" (amber)
- [ ] Demo state selector visible at bottom
- [ ] Clicking buttons changes UI state
- [ ] No TypeScript errors: `npx tsc --noEmit`

## Testing States

Click buttons at bottom of page:

1. **Live** (default) - 8,450 nuts, 84.5% complete, amber status
2. **Near Target** - 9,850 nuts, 98.5% complete, amber status
3. **Target Reached** - 10,250 nuts, 102.5%, red "STOP HARVEST"
4. **Offline** - Cached data display, gray indicator
5. **Empty** - No data, "Harvest has not started"

## Important Notes

- All mock data is in `lib/harvest-live-counter-mock.ts`
- Components are fully typed with TypeScript interfaces
- State selector at bottom is for development only
- No API integration in Phase 2 (UI-only)
- Replace mock data with real API calls in Phase 3

## Documentation

- **README**: HARVEST_LIVE_COUNTER_PHASE2_README.md
  - Comprehensive overview
  - Component descriptions
  - Integration points

- **Component Map**: HARVEST_LIVE_COUNTER_COMPONENT_MAP.md
  - Architecture details
  - Data flow
  - Props and interfaces

## Troubleshooting

### "Cannot find module" errors
- Ensure all files are copied to correct paths
- Check import paths use `@/` aliases
- Verify tsconfig.json has path aliases

### Tailwind styles not applied
- Verify Tailwind CSS is installed and configured
- Check globals.css includes `@tailwind` directives
- Rebuild if needed: `npm run build`

### TypeScript errors
- Run `npm install` to ensure all dependencies
- Check lucide-react version matches project
- Run `npx tsc --noEmit` to see all errors

## Support

All component interfaces and mock data are fully documented in the README and Component Map files.
